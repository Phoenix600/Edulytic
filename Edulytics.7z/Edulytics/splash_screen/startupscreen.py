# import your module here 
from tkinter import ttk
from tkinter.ttk import Progressbar
from tkinter import *

# creatng the root window from tkinter class Tk()
root = Tk()
width_of_window = 427
height_of_window = 250 

screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

x_coordinate = (screen_width/2) - (width_of_window/2)
y_coordinate = (screen_height/2) - (height_of_window/2)

# setting the size of the root widget screen 
root.geometry("%dx%d+%d+%d"%(width_of_window,height_of_window,x_coordinate,y_coordinate))

# removing the windows upper tool-bar to create the startup-screen effect
root.overrideredirect(1)

root.mainloop()
