from email import message
from tkinter import *
# creating the root widget 
root = Tk()
e = Entry(root,width=50)
e.pack()
e.insert(0,"Enter your name : ")

def myclick():
    Hello = "Welcome " + e.get()
    Message = Label(root,text=Hello)
    message.pack()

# creating the button type object 
button = Button(root,text="Get Started",padx=5,fg="#363434",bg="#ffd500",round="5")
button.pack()
root.mainloop()