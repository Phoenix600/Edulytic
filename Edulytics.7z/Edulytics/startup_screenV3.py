# import your modules here 
from cProfile import label
from tkinter import *
from tkinter import ttk
from tkinter.ttk import Progressbar
from PIL import ImageTk, Image
import time 

# Write main code here 
""" Creating the w as tkinter root widget """
w = Tk()
w.geometry('427x250')

# setting up splash screen size 
width_of_window     = 427
height_of_window    = 250

# detecting the screen size by built in functions 
screen_width = w.winfo_screenwidth()
screen_height = w.winfo_screenheight()

# setting up the co-ordinates to place the screen 
x_coordinate = (screen_width/2)-(width_of_window/2)
y_coordinate = (screen_height/2)-(height_of_window/2)
w.geometry("%dx%d+%d+%d"%(width_of_window,height_of_window,x_coordinate,y_coordinate))

# this line removes the uppper tool/Task bar 
w.overrideredirect(1) 
#  Use the above line , when code is finished 

s = ttk.Style()
s.theme_use('clam')
s.configure("red.Horizontal.TProgressbar",foreground='red',background='#4f4f4f')
progress = Progressbar(w,style="red.Horizontal.TProgressbar",orient=HORIZONTAL,length=500,mode='determinate')
# Progress Bar 

def new_win():
    q = Tk()
    q.title("Main window")
    q.geometry("1920x1080")
    l1=Label(q,text="ADD TEXT HERE",fg="grey",bg=None)
    l = ('Calibri (Body)',24,'bold')
    l1.config(font=l)
    l1.place(x=80,y=100)
    
    q.mainloop()

def bar():
    l4 = Label(w,text="Loading...",fg="white",bg="#6C63FF")
    lst4=('Calibri (Body)',10)
    l4.config(font=lst4)
    l4.place(x=15,y=206)
    r = 0
    for i in range(100):
        progress['value'] = r
        w.update_idletasks()
        time.sleep(0.03)
        r+=1
    w.destroy()
    new_win()

progress.place(x=-10,y=235)


a ="#6c63ff"
Frame(w,width=427,height=241,bg=a).place(x=0,y=0)
b1 = Button(w,width=10,height=1,text="Get Started",command=bar,border=0,fg=a,bg="white")
b1.place(x=170,y=200)

# label 
# l1 = label(w,)

w.mainloop()