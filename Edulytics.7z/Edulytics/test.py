from tkinter import *

root = Tk()
root.title("Login")
