# import ypur modules here 
import pandas as pd

DataBase = pd.read_csv('dataBasev3.csv')
print(DataBase)
print(DataBase['Name'],DataBase['Skills'])
print(DataBase[['Name','Skills']])

