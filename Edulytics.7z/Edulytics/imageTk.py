from tkinter import *
from turtle import back
from PIL import ImageTk,Image

root = Tk()

frame = Canvas()
frame.config(bg="#6c63ff",border=0)
my_image = ImageTk.PhotoImage(Image.open("LOGO.png"))
my_label = Label(image=my_image,border=0)
root.overrideredirect(1)
my_label.place(x=50,y=50)
frame.pack()
root.config(border=0)
root.mainloop()