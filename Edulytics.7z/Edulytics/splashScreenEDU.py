# import your modules here  
from tkinter import *
from tkinter.ttk import Progressbar
import time
from click import progressbar
from matplotlib.ft2font import BOLD

# write main code here 

""" Creating teh w as tkinter root widget"""
w = Tk()
w.geometry('427x250')

# setting up the splash screen size 
width_of_window = 427
height_of_window = 250

# detecting teh screen size by built in funcions here 
screen_width=w.winfo_screenwidth()
screen_height=w.winfo_screenheight()

# setting up the co-ordinates to place teh screen
x_coordinate = (screen_width/2)-(width_of_window/2)
y_coordinate = (screen_height/2)-(height_of_window/2)
w.geometry("%dx%d+%d+%d"%(width_of_window,height_of_window,x_coordinate,y_coordinate))

# this line remove the upper tool bar of the splash screen
# w.overrideredirect(1)

def main_window():
    q = Tk()
    q.geometry('427x250')
    l1 = Label(w,text="Welcome to Edulytics",font=('Segoe UI',24),fg='dark grey',bg=None)
    l1.place(x=80,y=100)
    q.mainloop()    

# defining the progress bar here
def bar() :
    l4 = Label(w,text='Loading...',fg='white',bg='#279497')
    lst4 = ('Calibri (Body)',10)
    l4.configure(font=lst4)
    l4.place(x=0,y=210)
    r = 0
    for i in range(100):
        Progressbar['value'] = r
        w.update_idletasks()
        time.sleep(0.03)
        r+=1 
    w.destroy()



main_window()

# tkinter mainloop screen 
w.mainloop()
 
