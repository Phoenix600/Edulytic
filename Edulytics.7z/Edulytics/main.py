# import your modules here 
from click import command
import pandas as pd 
from tkinter import *
import matplotlib.pyplot as plt
import smtplib as smt
import random as rnd
from docx import Document

# creating the tkinter splash screen
splash_root = Tk()
splash_root.title("Edulytics")
splash_root.geometry("300x200")

splash_lebel = Label(splash_root,text="Edulytics",font=("Helvetica",18))
splash_lebel.pack()


# main function to display the main window
def mainWindow():
    # destroying the splash screen 
    splash_root.destroy()
    # creating the tkinter root widget 
    root = Tk()
    root.title("Edulytics")
    root.geometry("500x550")

# setting the splash timer
splash_root.after(3000,mainWindow)

mainloop()
