from fileinput import filename
import imghdr
import smtplib
from email.message import EmailMessage 
import ssl

from matplotlib import image

password = "ydlioaihkqhfmdqa"
email_sender = "edulytics.india@gmail.com"
email_reciever = "pranayramteke613@gmail.com"

subject = "Baby I Love You"
body = "I love you from my heart"


em = EmailMessage()
em['From'] = email_sender
em['To'] = email_reciever
em['Subject'] = subject
em['Body']  = body
# em.add_header('Content-Disposition', 'attachment', filename='diya.jpg')
em.set_content(body)

with open("diya.jpg",'rb') as f:
    image_data = f.read()
    image_type = imghdr.what(f.name)
    image_name = f.name
em.add_attachment(image_data,maintype='image',subtype=image_type,filename=image_name)
# em.set_content(body)

files = ["diya.pdf"]
for file in files :
    with open(file,'rb') as f:
        file_data = f.read()
        file_name = f.name
    em.add_attachment(file_data,maintype='application',subtype='octet-stream',filename=file_name)
context = ssl.create_default_context()

with smtplib.SMTP_SSL('smtp.gmail.com',465,context=context) as smtp :
    smtp.login(email_sender,password)
    smtp.sendmail(email_sender,email_reciever,em.as_string())
